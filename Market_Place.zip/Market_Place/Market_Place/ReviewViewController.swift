//
//  ReviewViewController.swift
//  Market_Place
//
//  Created by MADHUSOODAN RAO M S on 07/05/21.
//

import UIKit
import AlamofireImage
import Parse

class ReviewViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var itemNameLabel: UITextField!
    
    @IBOutlet weak var usernameLabel: UITextField!
    
    
    @IBOutlet weak var review: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func onPost(_ sender: Any) {
        let post = PFObject(className: "PostsReview")
        
        post["itemname"] = itemNameLabel.text!
        post["item_publish_user"] = usernameLabel.text!
        
        post["author"] = PFUser.current()!
        post["review"] = review.text!
        
        post.saveInBackground { (success, error) in
            if success {
                self.dismiss(animated: true, completion: nil)
                print("Saved!")
            } else {
                print("Failed!")
            }
        }
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
